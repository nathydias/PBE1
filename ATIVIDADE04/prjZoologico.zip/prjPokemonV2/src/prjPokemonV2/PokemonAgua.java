package prjPokemonV2;

public class PokemonAgua {
    //Metodos da subclasse
	public void Surfar () {
		
	}
	public void cannhaodAgaua();
	
	public void atacar() {
		System.out.println("Atacou com Agua");
	}
}

