package prjPokemonV2;

public class prjPokemon {
 String Nome;
 String Tipo;
private int Hp;
private int Nível;
private int Defesa;

public void atacar() {
	System.out.println("Atacou");
}
public void evoluir() {
	System.out.println("Evoluiu");
}
}
