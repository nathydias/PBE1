package prjPokemonV2;

public class PokemonVoador {
public void voar() {

	public void ataqueAsa() {

	}

	public void atacar() {
		System.out.println("Atacou voando");
	}
}
