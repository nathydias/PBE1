package prjPokemonV2;

public class PokemonFogo {
public void bolaFogo() {
	int parametroDefesa){
}
public void lancaChamas();

public void atacar() {
	System.out.println("Atacou com Fogo");
}

//Metodos de subclasses 

public void bolaFogo();
}


