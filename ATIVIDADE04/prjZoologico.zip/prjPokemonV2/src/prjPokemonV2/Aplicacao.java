package prjPokemonV2;

public class Aplicacao {
 
	public static void main(String[] args) {
		 prjPokemon Charmander = new  prjPokemon();
		Charmander.setNome("Chamander");
		Charmander.setTipo("Fogo");
		Charmander.setNivel("17");
		Charmander.setHp(50);
		Charmander.setDefesa(40);
		
		prjPokemon Flareon = new prjPokemon("Flareon", "Fogo", 25,95,60);
		prjPokemon Megicarp = new prjPokemon("Megicarp", "Agua", 10, 40, 50);
		prjPokemon Veporeon = new prjPokemon("Vaparon", "Voador", 7, 50,30);
		prjPokemon hoothoot = new prjPokemon("hoothoot", "Voador", 10,40,30);
		prjPokemon Pikachu = new prjPokemon("Pikachu", "eletrico", 20, 90,70);
		
		Charmander.atacar();
		Charmander.evoluir();
		Charmander.exibirInfo();
		
		Flareon.atacar();
		Flareon.evoluir();
		Flareon.exibirInfo();
		
		Megicarp.atacar();
		Megicarp.evoluir();
		Megicarp.exibirInfo();
		
		 Veporeon.atacar();
		 Veporeon.evoluir();
		 Veporeon.exibirInfo();
		 
		 hoothoot.atacar();
		 hoothoot.evoluir();
		 hoothoot.exibirInfo();
		 
		 Pikachu.atacar();
		 Pikachu.evoluir();
		 Pikachu.exibirInfo():
	}
}
