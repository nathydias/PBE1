package prjCarro;
import java.util.Scanner;
public class NovoCarro {

	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    Carro carro01 = new Carro();
    Carro carro02 = new Carro("VW","GOL",0);
    System.out.println("qual a marca?");
    carro01.marca = sc.nextLine();
    
    System.out.println("qual o modelo?");
    carro01.modelo = sc.nextLine();

    System.out.println("qual a sua velocidade?");
    carro01.velocidade = sc.nextInt();
    
    System.out.println("Opções:");
    System.out.println("1. Acelerar");
    System.out.println("2. Frear");
    System.out.println("3. Buzinar");
    System.out.println("Escolha uma opção:");
    int escolha =sc.nextInt();
    
    if (escolhas == 1) {
       System.out.println("Quanto voce equer acelerar? ");
       carro01.acelerar(sc.nextInt());
    }
    else if (escolha == 2) {
    	System.out.println("Quanto voce quer desacelerar?");
    	carro01.frear(sc.nextInt());
    	
    	else if (escolha == 3) {
    	carro01.buzinar();
    	}
    	else {
    		System.out.println("Opção invalida");
    	}
    	 System.out.println("A marca do carro é: " + carro01.getMarca());
    	 System.out.println("O modelo do carro: " + carro01.getModelo());
    	 System.out.println("A velocidade atual é: " + carro01.getvelocidade());
    	 
    	 sc.close();
    }
    
    }

	}

}
