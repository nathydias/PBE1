package br.combibliotecasenai.principal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecasenaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
