package com.senaidev.primeirospring.services;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;

import com.senaidev.primeirospring.dto.DtoEndereco;

public class ApiServico {

	DtoEndereco endereco = new DtoEndereco();

	public DtoEndereco getEndereco (String cep) {
		try {
		    HttpClient client = HttpClient.newHttpClient();
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create("https://viacep.com.br/ws/"+ cep +"/json/")).build();
		} catch (Exception erro) {
			System.out.println(erro.getMessage ());
		}
		
		return  endereco;
	}
	
	
	
}
