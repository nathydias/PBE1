package com.senaidev.primeirospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeirospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
